const products = [
    { id: 1, name: "Tomatoes", price: 2, image: "https://via.placeholder.com/150" },
    { id: 2, name: "Potatoes", price: 1.5, image: "https://via.placeholder.com/150" },
    { id: 3, name: "Carrots", price: 3, image: "https://via.placeholder.com/150" },
];

let cart = [];

const productList = document.getElementById("product-list");
const cartItems = document.getElementById("cart-items");
const totalPrice = document.getElementById("total-price");
const searchInput = document.getElementById("search");

// Display Products
function displayProducts(items) {
    productList.innerHTML = "";
    items.forEach(product => {
        const productCard = `
            <div class="product">
                <img src="${product.image}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>Price: $${product.price}</p>
                <button onclick="addToCart(${product.id})">Add to Cart</button>
            </div>
        `;
        productList.innerHTML += productCard;
    });
}

// Add to Cart
function addToCart(id) {
    const product = products.find(p => p.id === id);
    cart.push(product);
    updateCart();
}

// Update Cart
function updateCart() {
    cartItems.innerHTML = "";
    let total = 0;
    cart.forEach(item => {
        total += item.price;
        cartItems.innerHTML += `<li>${item.name} - $${item.price}</li>`;
    });
    totalPrice.innerText = total.toFixed(2);
}

// Search Functionality
searchInput.addEventListener("input", () => {
    const searchText = searchInput.value.toLowerCase();
    const filteredProducts = products.filter(p => p.name.toLowerCase().includes(searchText));
    displayProducts(filteredProducts);
});

// Initial Load
displayProducts(products);
